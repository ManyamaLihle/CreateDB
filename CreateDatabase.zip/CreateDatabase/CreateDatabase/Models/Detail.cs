﻿namespace CreateDatabase.Models
{
    public class Detail
    {
        public int Id { get; set; }
        public string ItemDescription { get; set; }   
        public int Quantity { get; set; }   
        public double UnitPrice { get; set; }
        public int  TotalLine { get; set; }
        public Detail()
        {

        }
    }
}
