﻿namespace CreateDatabase.Models
{
    public class Invoices
    {
        public int Id { get; set; } 
        public int InvoiceNumber { get; set; }
        public DateTime InvoiceDate { get; set; }
        public string CustomerName { get; set; }
        public string  CustomerAddress { get; set; }
        public int CustomNumber { get; set; }

        public Invoices()
        {

        }


    }
}
