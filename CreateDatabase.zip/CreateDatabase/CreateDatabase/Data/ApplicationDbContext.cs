﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using CreateDatabase.Models;

namespace CreateDatabase.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<CreateDatabase.Models.Detail>? Detail { get; set; }
        public DbSet<CreateDatabase.Models.Invoices>? Invoices { get; set; }
    }
}